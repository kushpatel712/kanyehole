package com.dropout.kanyehole;

public class ObstacleGenerator {
    private static final String colors[] = { "Red", "Green", "Blue", "White", "Black" };

    public void generate(ObjectView drawer,int mScrWidth, int mScrHeight, int numObj){
        for(int i=0; i < numObj; i++) {
            System.out.println("Object: "+ i);
            Obstacle obstacle = (Obstacle)ObstacleFactory.getObstacle(getRandomColor(),mScrWidth, mScrHeight, getRandomAngle());
            drawer.registerObject(obstacle);
        }
    }
    private static String getRandomColor() {
        return colors[(int)(Math.random()*colors.length)];
    }
    private static int getRandomAngle() { return (int)(Math.random()*360);};
}