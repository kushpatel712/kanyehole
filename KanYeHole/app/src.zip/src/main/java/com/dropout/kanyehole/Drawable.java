package com.dropout.kanyehole;

import android.graphics.Canvas;

/**
 * Created by Kush on 4/2/2015.
 */
public interface Drawable {
    public void draw(Canvas canvas, int height, int width);
}
