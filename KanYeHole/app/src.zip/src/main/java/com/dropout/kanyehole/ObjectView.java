package com.dropout.kanyehole;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.Display;
import android.view.View;
import 	android.graphics.RectF;

import java.util.ArrayList;


public class ObjectView extends View {

    private final Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ArrayList<Drawable> drawList = new ArrayList<Drawable>();
  //  public RectF hi;

   //construct new ball object
    public ObjectView(Context context, int color) {
        super(context);
        //color hex is [transparency][red][green][blue]
        if (color==0)
        mPaint.setColor(0xFF00FF00); //not transparent. color is green
        else
        	mPaint.setColor(0XFFFF0000);
        mPaint.setColor(Color.BLACK);
        mPaint.setStrokeWidth(50);
    }
    public int getListLength(){ return drawList.size();};
    public void registerObject(Drawable obj){
        drawList.add(obj);
    }
    //called by invalidate()	
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Drawable obj: drawList){
            obj.draw(canvas,getResources().getDisplayMetrics().heightPixels,getResources().getDisplayMetrics().widthPixels);
        }

    }
}
