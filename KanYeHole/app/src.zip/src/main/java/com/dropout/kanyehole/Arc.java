package com.dropout.kanyehole;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

/**
 * Created by Kush on 4/1/2015.
 */
public class Arc implements Drawable{
    /*
    * TODO: Make me a Flyweight! :D
    * */
   // public class Obstacles
    //{
    //}
    public boolean drawn = false;
    private static Arc instance = new Arc(0,0);
    private android.graphics.PointF position, speed;
    private double angle = 0;
    private int mScrWidth, mScrHeight;
    private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    public void draw(Canvas canvas, int height, int width){
        paint.setColor(Color.GREEN);
        int yyyy = height/4;
        int xxxx = width/2;
        RectF hi=new RectF(xxxx-xxxx/5,yyyy-xxxx/5,yyyy+xxxx/5,yyyy-+xxxx/5);
        paint.setStrokeWidth(10);
        float angs= (float)angle;
        angs+=0.5f;
        canvas.drawArc(new RectF(xxxx-(xxxx*2/5),yyyy-(xxxx*2/5),xxxx+(xxxx*2/5),yyyy+(xxxx*2/5)), (angs-30)%360, 60, false, paint);
        drawn = true;
    }
    private Arc(int mScrWidth, int mScrHeight ){
        position = new android.graphics.PointF();
        speed = new android.graphics.PointF();
        position.x = mScrWidth/2;
        position.y = mScrHeight/4;
        speed.x = 0;
        speed.y = 0;
        this.mScrWidth = mScrWidth;
        this.mScrHeight = mScrHeight;
    }

    public static Arc getInstance()
    {
        if(instance == null)
            instance = new Arc(0,0);
        return instance;
    }

    public void setXPosition(float x){
        position.x = x;
    }
    public void setYPosition(float y){
        position.y = y;
    }
    public void setPosition(float x, float y){
        position.x = x;
        position.y = y;
    }
    public void updatePosition(ObjectView v){

        position.x += speed.x;
        position.y += speed.y;
        angle += speed.x;
        drawn = false;
        //if ball goes off screen, reposition to opposite side of screen
        //update ball class instance
    }
    public double getAngle() {return angle;}
    public float getXPosition(){
        return position.x;
    }
    public float getYPosition(){
        return position.y;
    }
    public float getXSpeed(){
        return speed.x;
    }
    public float getYSpeed(){
        return speed.y;
    }
    public void setSpeed(float xSpeed, float ySpeed){
        speed.x = xSpeed;
        speed.y = ySpeed;
    }

}
